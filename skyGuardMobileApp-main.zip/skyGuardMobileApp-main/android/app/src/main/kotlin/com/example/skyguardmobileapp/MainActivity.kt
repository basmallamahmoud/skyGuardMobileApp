package com.example.skyguardmobileapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
