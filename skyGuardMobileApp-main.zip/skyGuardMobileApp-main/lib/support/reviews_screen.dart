import 'package:flutter/material.dart';

class ReviewsScreen extends StatelessWidget {
  const ReviewsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("User Reviews")),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: 4, // Placeholder فقط
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              leading: const Icon(Icons.person),
              title: const Text("User Name"),
              subtitle: const Text("Great safety monitoring system!"),
              trailing: const Icon(Icons.star, color: Colors.amber),
            ),
          );
        },
      ),
    );
  }
}