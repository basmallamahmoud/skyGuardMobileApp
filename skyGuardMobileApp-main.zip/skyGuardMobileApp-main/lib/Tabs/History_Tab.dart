import 'package:flutter/material.dart';
import '../trip/trip_details_screen.dart';
import '../accidents/accident_details_screen.dart';

enum AccidentState {
  loading,
  empty,
  loaded,
}
enum TripsState {
  loading,
  empty,
  loaded, // للباك بعدين
}



class HistoryTab extends StatelessWidget {
  const HistoryTab({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("History"),
          bottom: const TabBar(
            tabs: [
              Tab(text: "Trips", icon: Icon(Icons.route)),
              Tab(text: "Accidents", icon: Icon(Icons.warning)),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            TripsTab(),
            AccidentsTab(),
          ],
        ),
      ),
    );
  }
}



class TripsTab extends StatefulWidget {
  const TripsTab({Key? key}) : super(key: key);

  @override
  State<TripsTab> createState() => _TripsTabState();
}

class _TripsTabState extends State<TripsTab> {
  TripsState state = TripsState.empty;

  @override
  Widget build(BuildContext context) {
    return _buildBody();
  }

  Widget _buildBody() {
    if (state == TripsState.loading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (state == TripsState.empty) {
      return _emptyState();
    }

    return _tripsList();
  }

  // ================= EMPTY STATE =================
  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.route, size: 80, color: Colors.grey),
          const SizedBox(height: 16),
          const Text(
            "No trips yet",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 8),
          const Text(
            "Start driving to see trip history",
            style: TextStyle(color: Colors.grey),
          ),
          const SizedBox(height: 20),

          // 🔄 زر Refresh
          ElevatedButton(
            onPressed: () {
              setState(() => state = TripsState.loading);

              Future.delayed(const Duration(seconds: 1), () {
                if (!mounted) return;
                setState(() => state = TripsState.empty);
              });
            },
            child: const Text("Refresh"),
          ),

          const SizedBox(height: 12),

          // 📄 زر يفتح Trip Details
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const TripDetailsScreen(),
                ),
              );
            },
            child: const Text("Open Trip Details"),
          ),
        ],
      ),
    );
  }

  // ================= LIST PLACEHOLDER =================
  Widget _tripsList() {
    return ListView.builder(
      itemCount: 0, // هييجي من الباك بعدين
      itemBuilder: (context, index) {
        return const SizedBox();
      },
    );
  }
}

class AccidentsTab extends StatefulWidget {
  const AccidentsTab({super.key});

  @override
  State<AccidentsTab> createState() => _AccidentsTabState();
}

class _AccidentsTabState extends State<AccidentsTab> {

  AccidentState state = AccidentState.empty;

  @override
  Widget build(BuildContext context) {
    return _buildBody();
  }

  Widget _buildBody() {
    if (state == AccidentState.loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (state == AccidentState.empty) {
      return _emptyState();
    }

    return _accidentsList();
  }

  // ================= EMPTY STATE =================
  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.car_crash, size: 80, color: Colors.grey),
          const SizedBox(height: 16),
          const Text(
            "No accidents recorded",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 8),
          const Text(
            "Your trips are safe so far",
            style: TextStyle(color: Colors.grey),
          ),

          const SizedBox(height: 20),

          // 🔥 زر فتح تفاصيل الحادث
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const AccidentDetailsScreen(),
                ),
              );
            },
            child: const Text("Open Accident Details"),
          ),
        ],
      ),
    );
  }

  // ================= LIST PLACEHOLDER =================
  Widget _accidentsList() {
    return ListView.builder(
      itemCount: 0,
      itemBuilder: (context, index) {
        return const SizedBox();
      },
    );
  }
}