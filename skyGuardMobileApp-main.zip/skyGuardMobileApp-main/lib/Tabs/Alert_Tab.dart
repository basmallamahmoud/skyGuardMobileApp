import 'package:flutter/material.dart';
import '../alerts/alert_details_screen.dart';

enum AlertsState {
  loading,
  empty,
  loaded,
}

class AlertTab extends StatefulWidget {
  const AlertTab({super.key});

  @override
  State<AlertTab> createState() => _AlertTabState();
}

class _AlertTabState extends State<AlertTab> {
  AlertsState state = AlertsState.empty;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Alerts"),
        actions: [
          IconButton(
            onPressed: () {
              setState(() => state = AlertsState.loading);
              Future.delayed(const Duration(seconds: 1), () {
                if (!mounted) return;
                setState(() => state = AlertsState.empty);
              });
            },
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _buildBody(context),
    );
  }

  Widget _buildBody(BuildContext context) {
    if (state == AlertsState.loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (state == AlertsState.empty) {
      return _emptyState(context);
    }

    return _alertsList(context);
  }

  Widget _emptyState(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.notifications_off, size: 80, color: Colors.grey),
            const SizedBox(height: 16),
            const Text(
              "No alerts",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            const Text(
              "When an accident is detected, alerts will appear here.",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AlertDetailsScreen()),
                );
              },
              child: const Text("Open Alert Details"),
            ),
          ],
        ),
      ),
    );
  }

  Widget _alertsList(BuildContext context) {
    return ListView.builder(
      itemCount: 0, // من الباك بعدين
      itemBuilder: (context, index) => const SizedBox(),
    );
  }
}